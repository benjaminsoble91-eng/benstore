# Benstore — setup (about 5 minutes)

## On your Mac
1. Unzip **Benstore Installer.zip**. Because the app isn't notarized, run this once in Terminal:
   `xattr -cr ~/Downloads/"Benstore Installer.app"`
2. Open **Benstore Installer** and follow its 4 steps:
   1. **Connect.** Plug in your iPhone and unlock it. The installer finds it and asks it to **Trust** this Mac. Tap Trust. You don't need Finder or any pairing tools.
   2. **Sign in** with any Apple ID (free works). Leave "Also sign in Benstore on the iPhone" ticked, so you only type it once.
   3. **Install.** One progress bar.
   4. **Finish on iPhone.** A checklist that updates itself:
      - **Developer Mode:** the installer can make the switch appear. Turn it on, and the iPhone restarts.
      - **Trust developer:** Settings › General › VPN & Device Management › your Apple ID › Trust.
      - **LocalDevVPN:** free from the App Store. Open it and tap Connect.

## On your iPhone
Open Benstore. You're already signed in. If anything is still missing, the **Finish setup** card says what and gives you a button for it.

- **+** adds an app. You can also share an .ipa to Benstore from Files or Safari.
- **Pull down** to refresh everything.
- Benstore sends a notification the day before anything expires, and refreshes in the background when it can.
- If LocalDevVPN is off when Benstore needs it, Benstore asks you to connect it, then carries on by itself.

Free Apple IDs: apps last 7 days, you can have 3 at once (Benstore counts as one), and you get 10 new App IDs per week.

Terminal version of the installer: `"Benstore Installer.app/Contents/MacOS/Benstore Installer" --cli [--ipa App.ipa]`

## Updating (no reinstalling)
- iPhone: Settings → Benstore → **Check for Updates** → **Update**. Benstore downloads the new version, signs it with your certificate and installs it over itself. Your apps, sign-in and settings stay. It also checks by itself when you open it.
- Mac: Benstore Installer menu → **Check for Updates…** (it also checks on launch). It replaces itself and reopens.
- Publishing a new version: bump `VERSION`, build, then `tools/publish_update.sh ~/benstore "what's new"` and push the benstore repo. Both apps read `https://benjaminsoble91-eng.github.io/benstore/update.json` (you can change the link in Settings → Update Source).
- The update is checked against a SHA-256 in update.json before installing, so a broken or swapped download is refused.
